#!/usr/bin/env python
# coding: utf-8

# In[24]:


import numpy as np # linear algebra
import pandas as pd # data processing, CSV file I/O (e.g. pd.read_csv)
import pickle

from tslearn.preprocessing import TimeSeriesScalerMinMax
from tslearn.metrics import dtw_subsequence_path

# import xgboost as xgb


# In[25]:


dataset_folder = "../all"
get_ipython().system('ls {dataset_folder}')


# In[26]:


def read_pickle(name):
    with open(name, 'rb') as f:
        data = pickle.load(f)
    return data


# In[27]:


xg_model = read_pickle("xg_model")
shapelets = read_pickle("shapelets")
print(shapelets.shape)


# In[28]:


classes = np.array([ 6, 15, 16, 42, 52, 53, 62, 64, 65, 67, 88, 90, 92, 95, 99])
classes


# In[29]:


def normalize(ts, ts_err):
    ts /= (ts_err + 1) # +1 to avoid zero division
    ts = np.nan_to_num(ts)
    ts = TimeSeriesScalerMinMax().fit_transform(ts)
    return ts


# In[30]:


def distanceToShapelet(ts, shapelet):
    path, dist = dtw_subsequence_path(shapelet, ts)
    return dist


# In[31]:


def distanceToShapelets(ts, shapelets=shapelets):
    return [distanceToShapelet(ts, shapelet) for shapelet in shapelets]


# In[32]:


step = 1
nb_of_passband = 6
max_mjd = 1094
print(nb_of_passband, max_mjd, sep="\n")


# In[33]:


def format_time_series(data):
    X = []
    X_err = []
    s0 = int(data.shape[0] / nb_of_passband)
    x, x_err = [], []
    for p in range(nb_of_passband):
        x = np.append(x, data[data.passband==p].flux.values)
        x_err = np.append(x_err, data[data.passband==p].flux_err.values)
    X.append(x.reshape(s0, nb_of_passband))
    X_err.append(x.reshape(s0, nb_of_passband))
    return np.array(X), np.array(X_err)


# In[34]:


def mjdToPredict(mjdToExclude, minMjd, maxMjd, step):
    return np.array(list(set(range(minMjd, maxMjd+1, step)) - set(mjdToExclude)))


# In[35]:


def fill_missing_flux(objectDf, maxMjd, step):
    objectDf.mjd = objectDf[["mjd"]].astype(np.int64)
    objectDf.mjd = objectDf.mjd - objectDf.mjd.min()
    instance = objectDf.groupby(["passband", "mjd"]).mean().reset_index()
    meanByPassband = instance.groupby("passband").mean()[["flux", "flux_err"]]
    frames = [instance]
    for p in range(6):
        toExclude = instance[instance.passband==p].mjd
        toPredict = mjdToPredict(toExclude, 0, maxMjd, step)
        nb = len(toPredict)
        frames.append(pd.DataFrame({
            'mjd': toPredict,
            'flux': [meanByPassband.loc[p].flux]*nb,
            'flux_err': [meanByPassband.loc[p].flux_err]*nb,
            'detected': [-1] * nb,
            'passband': [p]*nb,
            'object_id': [objectDf.object_id.values[0]]*nb
        }))
    return pd.concat(frames, sort=False)


# In[36]:


columns = ["object_id"]
columns.extend([f"class_{c}" for c in classes])
submission = pd.DataFrame(columns = columns)
submission


# In[37]:


def predict_batch(test_df):
    instance = fill_missing_flux(test_df, max_mjd, step)
    ts, ts_err = format_time_series(instance)
    ts_norm = normalize(ts, ts_err)
    dist_vec = distanceToShapelets(ts_norm[0], shapelets)
    preds = xg_model.predict_proba([dist_vec])[0]
    preds = np.concatenate(([test_df.object_id.values[0]], preds, [0]))
    submission.loc[submission.shape[0]] = preds


# In[38]:


max_nb_of_chunk = 10
start_at = 0
print("Starting at:", start_at)


# In[43]:


def predict_test_set(start_at=0):
    test_example = []
    curr_id = None
    i = 0
    for chunk in pd.read_csv("{}/test_set.csv".format(dataset_folder), chunksize=1000, skiprows=list(range(1, start_at+1))):
        i += 1
        if curr_id is None:
            curr_id = chunk.object_id.values[0]
        print(f"Batch {i}")
        test_example.append(chunk.copy())
        if chunk.object_id.values[-1] != curr_id:
            tail = pd.concat(test_example)
            obj_ids = tail.object_id.unique()
            while obj_ids.shape[0] > 1:
                one_object_df = tail[tail.object_id==obj_ids[0]]
                predict_batch(one_object_df)
                obj_ids = np.delete(obj_ids, 0)
                start_at += one_object_df.shape[0]
            test_example = [tail[tail.object_id.isin(obj_ids)]]
            current_id = None if tail.shape[0] == 0 else tail.object_id.values[0]    
#         if i != max_nb_of_chunk:
#             print("EOF")
#             break
    test_df = pd.concat(test_example)
    predict_batch(test_df)
    print("End at:", start_at)


# In[ ]:


get_ipython().run_cell_magic('time', '', 'predict_test_set(start_at=start_at)')


# In[ ]:


submission.object_id = submission.object_id.astype(np.int32, inplace=True)
submission.shape


# In[ ]:


submission.to_csv("submission.csv", index=False)
